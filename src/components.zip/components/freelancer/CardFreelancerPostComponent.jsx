import { useMemo } from "react";
import { useGetAllServicesQuery } from "../../services/serviceApi";
import FreelancerCard from "./FreelancerCard";

const FALLBACK_IMAGE  = "https://placehold.co/285x253?text=No+Image";
const FALLBACK_AVATAR = "https://placehold.co/32x32?text=F";

function formatDate(value) {
  if (!value) return "—";
  const d = typeof value === "number" ? new Date(value) : new Date(value);
  if (Number.isNaN(d.getTime())) return "—";
  const dd   = String(d.getDate()).padStart(2, "0");
  const mm   = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}

function getFirstImage(s) {
  if (Array.isArray(s?.jobImages) && s.jobImages.length > 0) return s.jobImages[0];
  if (Array.isArray(s?.imageUrls) && s.imageUrls.length > 0) return s.imageUrls[0];
  return FALLBACK_IMAGE;
}

export default function CardFreelancerPostComponent({ category = "Freelancer", searchText = "" }) {
  const { data: services = [], isLoading, isError } = useGetAllServicesQuery();

  const filtered = useMemo(() => {
    const q   = String(searchText || "").trim().toLowerCase();
    const cat = String(category   || "").trim().toLowerCase();

    return services.filter((s) => {
      const title   = String(s?.title          || "").toLowerCase();
      const desc    = String(s?.description    || "").toLowerCase();
      const catName = String(s?.category?.name || "").toLowerCase();

      const matchSearch   = !q   || title.includes(q) || desc.includes(q) || catName.includes(q);
      const matchCategory = !cat || cat === "freelancer" || cat === "all" || catName.includes(cat);

      return matchSearch && matchCategory;
    });
  }, [services, searchText, category]);

  const cards = useMemo(() => {
    return filtered.map((s) => ({
      id:          s?.id,
      image:       getFirstImage(s),
      title:       s?.title                   || "Untitled",
      description: s?.description             || "No description",
      tags:        [s?.category?.name].filter(Boolean),
      date:        formatDate(s?.createdAt),
      author:      s?.author?.fullName        || "Freelancer",
      avatar:      s?.author?.profileImageUrl || FALLBACK_AVATAR,
      authorId:    s?.author?.id              || null,  // ✅ pass author id
    }));
  }, [filtered]);

  return (
    <section className="w-full px-4 py-8">
      {isLoading && (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
        </div>
      )}

      {isError && (
        <p className="text-red-500 text-center py-8">Failed to load posts.</p>
      )}

      {!isLoading && !isError && (
        <>
          <div className="grid gap-x-[50px] gap-y-6 justify-items-center grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 max-w-[1240px] mx-auto">
            {cards.map((card) => (
              <FreelancerCard
                key={card.id}
                id={card.id}
                image={card.image}
                title={card.title}
                description={card.description}
                tags={card.tags}
                date={card.date}
                author={card.author}
                avatar={card.avatar}
                authorId={card.authorId}  // ✅ this enables profile navigation
                postType="service"
              />
            ))}
          </div>

          {cards.length === 0 && (
            <p className="text-gray-400 text-center mt-6">No services found.</p>
          )}
        </>
      )}
    </section>
  );
}